import sys

class SharedMemory:
    '''
    This class is being used for creating shared memory between threads
    to achieve concurrency. It contains two variables which are responsible
    for handling send and receive signals between routers and achieving
    convergence.
    '''
    def __init__(self, nRouters):
        self.sm = [0 for i in range(nRouters)]             #Variable for handling signals
        self.f = [0 for i in range(nRouters)]              #Variable for finding updates in tables

    def getMem(self, i):                                   #Getter and setter methods for variables 
        return self.sm[i]

    def setMem(self, i, v):
        self.sm[i] = v

    def getFlag(self, i):
        return self.f

    def setFlag(self, i, v):
        self.f[i] = v

    def getFlags(self):                                    #Method for finding whether all tables converged
        return sum(self.f)