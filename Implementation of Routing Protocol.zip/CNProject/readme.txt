This folder contains three .py files:

- module.py
- script1.py
- script2.py

module.py contains all the classes and functions necessary for running the application.

For the first test case, run script1.py using the following command:

Python script1.py 5000

we can also the command as : Python script1.py 6000

For the second test case, run script2.py using the following command:

python script2.py 5000