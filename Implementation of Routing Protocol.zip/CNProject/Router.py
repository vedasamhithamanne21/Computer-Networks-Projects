import socket
import sys
from datetime import datetime

class Router:
    '''
    This class is used to store the router configuration:
    - Name, ip address and port number
    It has information regarding the neighbours and routing table
    It is used to bind the UDP socket connection to the port
    Maintains a log of all the updates done
    '''
    def __init__(self, name, router_id, ip, port, nRouters):
        self.name = name                                   # Router configuration
        self.router_id = router_id
        self.ip = ip
        self.port = port
        self.nRouters = nRouters                           # Stores no.of routers in the network
        self.neighbours = {}                               # Stores the neighbours of the router as a hash table
        self.routingTable = [[int(1e3) for i in range(nRouters)],[i for i in range(nRouters)]]    # Routing Table 
        self.routingTable[0][int(router_id)-1] = 0              # Initializing the cost to itself as zero
        self.updates = 0
        self.log = []                                      # Log for the router
        self.sc = socket.socket(family = socket.AF_INET, type = socket.SOCK_DGRAM)       #Socket for the router
        self.sc.bind((ip, port))

    def addNeighbour(self, v, ip, port, w):                # Adds neighbour's information (name, ip, port, cost)
        self.neighbours[ip] = (v, port)
        self.routingTable[0][int(v)-1] = w
        self.routingTable[1][int(v)-1] = int(v)-1

    def getNeighbours(self):                               # Get the hash table containing the neighbours 
        return self.neighbours

    def getIP(self):                                       # Getter methods for ip address and port number
        return self.ip

    def getPort(self):
        return self.port 

    def sendTable(self, ip, port):                         # Sends the routing vector through the socket to (ip, port)
        msg = ''
        for i in range(self.nRouters):
            msg += str(self.routingTable[0][i])+' '
        data = str.encode(msg)
        self.sc.sendto(data, (ip, port))

    def receiveTable(self):                                # Receives routing vector of (ip, port) from the socket
        msg, addr = self.sc.recvfrom(16000)
        nt = []
        res = msg.strip().split()
        for i in range(self.nRouters):
            nt.append(int(res[i]))
        return self.updateTable(nt, addr)

    def updateTable(self, nt, addr):                       # Bellman-Ford Algorithm for updating the vector
        f = 1
        v = int(self.neighbours[addr[0]][0])-1
        for w in range(self.nRouters):
            res = ''
            if (self.routingTable[0][v]+nt[w] < self.routingTable[0][w]):    # Bellman-Ford Update
                res += 'IpAddress: ['+addr[0]+'] '
                res += 'Previous weight: '+str(self.routingTable[0][w])+' '
                self.routingTable[0][w] = self.routingTable[0][v]+nt[w]
                self.routingTable[1][w] = v+1
                res += 'Updated weight: '+str(self.routingTable[0][w])+'\n'
                f = 0
                self.updates += 1
                self.log.append(res)                                         # Logging the update
        return f

    def sendEndingMessage(self, ip, port, msg):                              # Sends the termination message to all routers
        data = str.encode(msg)                                               # After convergence
        self.sc.sendto(data, (ip, port))

    def receiveEndingMessage(self):                                          # Receives the termination message from a router
        msg, addr = self.sc.recvfrom(16000)                                  # After convergence

    def printLog(self):                                                      # Method to print the log
        for l in self.log:
            print(l)
        self.log.clear()

    def descTable(self, router_name_map):                                                     # Method to print the routing table
        print('Router {} with ip {}'.format(self.name, self.ip))
        print('Router Distance Next')
        for i in range(self.nRouters):
            print(router_name_map[i+1], end=" ")
            print(self.routingTable[0][i], end=" ")
            print(self.routingTable[1][i])
        print()

    def descRouter(self):                                                    # Method to create the termination message describing router
        msg = ''
        msg += 'Message from Router {} with ip {} and port {}\n'.format(self.name, self.ip, self.port)
        msg += '1002030416 1002061392\n'
        now = datetime.now()
        msg += '{}\n'.format(now.strftime('%d-%m-%Y %H:%M:%S'))
        msg += '{}\n'.format(self.updates)
        msg += '{}\n'.format(len(msg.encode('utf-8')))
        self.log.append(msg)
        return msg

    def unbind(self):                                                        # Closing the socket for the router
        self.sc.close()
