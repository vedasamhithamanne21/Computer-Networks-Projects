import socket
import sys
import threading
import time
from Router import Router
from SharedMemory import SharedMemory

def run(id, router, var):                               #Target function for the threads
    while True:
        if var.getMem(id) == 1:                            #Block for sending table to the neighbours
            cand = router.getNeighbours()
            for key in cand:
                router.sendTable(key, cand[key][1])
                var.setMem(int(cand[key][0])-1, 2)
            var.setMem(id, 0)

        if var.getMem(id) == 2:                            #Block for receiving table from any neighbour
            var.setFlag(id, router.receiveTable())
            var.setMem(id, 0)

        if var.getMem(id) == 3:                            #Signal denoting convergence and termination
            break

    time.sleep(0.5)

input_file = 'input2.config'
input_file_stream = open(input_file)
initial_port_number = int(sys.argv[1])
nRouters = int(input_file_stream.readline().rstrip('\n'))                                    # Input the no.of routers in the network
router = []                                                     # Stores the router instances
router_name_map = {}                                             # Stores the router instances

for i in range(nRouters):
    name,ip = input_file_stream.readline().rstrip('\n').split()
    router.append(Router(name, i+1, ip, initial_port_number+int(i), nRouters))      # Creating instance based on ip and port
    router_name_map[name] = i+1
    router_name_map[i+1] = name

var = SharedMemory(nRouters)                               # Shared Memory shared_memoryiable

edges = int(input_file_stream.readline().rstrip('\n'))                                       # Input the paths between routers in the network
sumRollnos = int("1002030416") % 100 + int("1002061392") % 100
is_even = sumRollnos % 2 == 0

for _ in range(edges):
    u, ip1, v, ip2, w = input_file_stream.readline().rstrip('\n').split()           # Add the neighbour information in the respective routers
     
    if(is_even and int(router_name_map[u]) ==1 and int(router_name_map[v]) ==2):
    	w = 1e3
    if(not is_even and int(router_name_map[u]) ==2 and int(router_name_map[v]) ==4):
    	w = 1e3	
    print("weight of ",u," to ",v," is ",w)	 
    router[int(router_name_map[u])-1].addNeighbour(router_name_map[v], ip2, initial_port_number+router_name_map[v]-1, int(w))
    router[int(router_name_map[v])-1].addNeighbour(router_name_map[u], ip1, initial_port_number+router_name_map[u]-1, int(w))

t = []
for i in range(nRouters):
    t.append(threading.Thread(target=run, args=(i,router[i],var)))     # Threads for sending and receiving the routing vectors
    t[i].start()

input_file_stream.close()

while var.getFlags() < nRouters:                           # Terminates when convergence is achieved
    for i in range(nRouters):
        while (var.getMem(i) != 0):                        # Check if the router is not updating
            pass
        var.setMem(i, 1)                                   # Signal for the router to send its routing vector to neighbours
        while (var.getMem(i) == 1):                        # Check if the router has finished sending to all its neighbours
            pass

for i in range(nRouters):                                  # Terminating all threads after convergence
    var.setMem(i, 3)
    t[i].join()

for i in range(nRouters):                                  # Prints the routing table of the router
    router[i].descTable(router_name_map)

for i in range(nRouters):                                  # Closes the socket of the router
    router[i].unbind()
