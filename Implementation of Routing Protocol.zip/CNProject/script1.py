import socket
import sys
import threading
import time
from Router import Router
from SharedMemory import SharedMemory

def run(id, router, var):                               #Target function for the threads
    while True:
        if var.getMem(id) == 1:                            #Block for sending table to the neighbours
            cand = router.getNeighbours()
            for key in cand:
                router.sendTable(key, cand[key][1])
                var.setMem(int(cand[key][0])-1, 2)
            var.setMem(id, 0)

        if var.getMem(id) == 2:                            #Block for receiving table from any neighbour
            var.setFlag(id, router.receiveTable())
            var.setMem(id, 0)

        if var.getMem(id) == 3:                            #Signal denoting convergence and termination
            break

    time.sleep(0.5)

input_file = 'input1.config'
input_file_stream = open(input_file)
initial_port_number = int(sys.argv[1])
nRouters = int(input_file_stream.readline().rstrip('\n'))                                    # Input the no.of routers in the network
router = []                                                     # Stores the router instances
router_name_map = {}

for i in range(nRouters):
    name,ip = input_file_stream.readline().rstrip('\n').split()
    router.append(Router(name, i+1, ip, initial_port_number+int(i), nRouters))      # Creating instance based on ip and port
    router_name_map[name] = i+1

var = SharedMemory(nRouters)                               # Shared Memory shared_memoryiable

edges = int(input_file_stream.readline().rstrip('\n'))                                       # Input the paths between routers in the network

for _ in range(edges):
    u, ip1, v, ip2, w = input_file_stream.readline().rstrip('\n').split()           # Add the neighbour information in the respective routers
    router[int(router_name_map[u])-1].addNeighbour(router_name_map[v], ip2, initial_port_number+router_name_map[v]-1, int(w))
    router[int(router_name_map[v])-1].addNeighbour(router_name_map[u], ip1, initial_port_number+router_name_map[u]-1, int(w))

t = []
for i in range(nRouters):
    t.append(threading.Thread(target=run, args=(i,router[i],var)))     # Threads for sending and receiving the routing vectors
    t[i].start()

input_file_stream.close()

while var.getFlags() < nRouters:                           # Terminates when convergence is achieved
    for i in range(nRouters):
        while (var.getMem(i) != 0):                        # Check if the router is not updating
            pass
        var.setMem(i, 1)                                   # Signal for the router to send its routing vector to neighbours
        while (var.getMem(i) == 1):                        # Check if the router has finished sending to all its neighbours
            pass

        router[i].printLog()                               # Prints all the updates for the router

for i in range(nRouters):                                  # Terminating all threads after convergence
    var.setMem(i, 3)
    t[i].join()

for i in range(nRouters):                                  # Block to send and receive the termination messages
    msg = router[i].descRouter()
    for j in range(nRouters):
        if i == j:
            continue
        router[i].sendEndingMessage(router[j].getIP(), router[j].getPort(), msg)
        router[j].receiveEndingMessage()
    router[i].printLog()                                   # Prints the termination message for the router

for i in range(nRouters):                                  # Closes the socket of the router
    router[i].unbind()