import sys
import requests
import time
import socket

def main():
    ip = sys.argv[1]
    port = sys.argv[2]
    file = "/" + sys.argv[3]

    sent_time = time.time()

    hostname = socket.gethostbyaddr(ip)[0]
    ip_address = socket.gethostbyname(hostname)

    url = "http://" + ip + ":" + port + file
    response = requests.get(url)

    if response.status_code == 200:
        with open(file.split('/')[-1], 'wb') as file:
            file.write(response.content)
            print('File downloaded successfully.')
    else:
        print(f'Error downloading file: {response.status_code} {response.reason}')

    received_time = time.time()
    
    print(f'Host Name: {hostname}')
    print(f"IP Address: {ip_address}")
    print(f'Round Trip Time: {str(received_time - sent_time)}s')


if __name__ == "__main__":
    main()