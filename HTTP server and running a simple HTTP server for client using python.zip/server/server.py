import sys
import socket
import threading


def client_thread(client_socket, client_address):
    request = client_socket.recv(1024).decode()

    print(request)

    file_requested = request.split()[1]

    try:
        with open(file_requested[1:], 'rb') as file:
            response = b"HTTP/1.1 200 OK\r\n\r\n" + file.read()
    except:
        response = b"HTTP/1.1 404 Not Found\r\n\r\nFile not found."

    client_socket.sendall(response)
    client_socket.close()

def main():
    port = int(sys.argv[1])

    print(f'Server listening on http://localhost:{port}')

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("localhost", port))
    server_socket.listen()

    while True:
        client_socket, client_address = server_socket.accept()

        my_thread = threading.Thread(target=client_thread, args=(client_socket, client_address))
        my_thread.start()


if __name__ == "__main__":
    main()