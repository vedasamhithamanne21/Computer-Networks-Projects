This repository contains two Python scripts for downloading files from a HTTP server and running a simple HTTP server.

# Client

`client.py` is a python script that allows you to download a file from an HTTP server using the command line. It takes three arguments:

	ip: The IP address of the HTTP server.
	port: The port number of the HTTP server.
	file: The path of the file on the HTTP server that you want to download.

Once you run the script, it will send an HTTP GET request to the server to download the file, and then save the contents of the response to a local file in the same directory. It will also measure the time it takes for the request and response to travel between your machine and the server, and print out some information about your connection to the server.

# Server

`server.py` is a Python script that allows you to run a simple HTTP server that listens for incoming client requests. Once a client sends a request to the server, the server will try to retrieve the requested file (specified in the request URL), and then send the contents of that file back to the client as an HTTP response.

It takes one argument:

	port: port number that the server should listen on as a command line argument when running the script. 

Once the server is running, you can send HTTP GET requests to the server using a web browser or a command line tool like curl.

`example.txt` is the file that will be served. You can add additional files here and serve them as you please.

## Usage
Start by running the server
```
python server.py <port>
```

To download a file from an HTTP server, run the download_file.py script from the command line with the following arguments:
```
python client.py <ip> <port> <file>
```

You can also download the file by visiting 
```
https://localhost:<port>/example.txt
```
